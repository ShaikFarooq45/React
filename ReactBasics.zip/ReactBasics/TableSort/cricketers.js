var players = [
    {
        "fullname": "Ravi Sharma",
        "age": 28,
        "gender": "Male",
        "strikerate": 85.4,
        "centuries": 5,
        "half_centuries": 12,
        "country": "India"
    },
    {
        "fullname": "James Anderson",
        "age": 41,
        "gender": "Male",
        "strikerate": 72.3,
        "centuries": 0,
        "half_centuries": 3,
        "country": "England"
    },
    {
        "fullname": "Kane Williamson",
        "age": 34,
        "gender": "Male",
        "strikerate": 74.6,
        "centuries": 25,
        "half_centuries": 40,
        "country": "New Zealand"
    },
    {
        "fullname": "Meg Lanning",
        "age": 32,
        "gender": "Female",
        "strikerate": 91.2,
        "centuries": 16,
        "half_centuries": 30,
        "country": "Australia"
    },
    {
        "fullname": "AB de Villiers",
        "age": 39,
        "gender": "Male",
        "strikerate": 135.4,
        "centuries": 25,
        "half_centuries": 53,
        "country": "South Africa"
    },
    {
        "fullname": "Stafanie Taylor",
        "age": 32,
        "gender": "Female",
        "strikerate": 84.7,
        "centuries": 13,
        "half_centuries": 40,
        "country": "West Indies"
    },
    {
        "fullname": "Virat Kohli",
        "age": 35,
        "gender": "Male",
        "strikerate": 130.2,
        "centuries": 77,
        "half_centuries": 45,
        "country": "India"
    },
    {
        "fullname": "Sophie Devine",
        "age": 34,
        "gender": "Female",
        "strikerate": 117.6,
        "centuries": 8,
        "half_centuries": 20,
        "country": "New Zealand"
    },
    {
        "fullname": "Rassie van der Dussen",
        "age": 34,
        "gender": "Male",
        "strikerate": 90.1,
        "centuries": 8,
        "half_centuries": 15,
        "country": "South Africa"
    },
    {
        "fullname": "Ellyse Perry",
        "age": 33,
        "gender": "Female",
        "strikerate": 98.5,
        "centuries": 18,
        "half_centuries": 55,
        "country": "Australia"
    }
]
