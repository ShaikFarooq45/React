var players = [

          {
            "fullName": "Sachin Tendulkar",
            "centuries": 100,
            "description": "Widely regarded as one of the greatest batsmen in the history of cricket, Sachin Tendulkar has scored 100 international centuries, the most by any player.",
            "image": "https://images-cricketcom.imgix.net/sachin-tendulkar-1693132548682?fit=crop&crop=face&auto=format&ixlib=react-9.8.0&h=250&w=180"
          },
          {
            "fullName": "Virat Kohli",
            "centuries": 76,
            "description": "One of the modern greats, Virat Kohli is known for his aggressive batting style and consistency across formats, with numerous records to his name.",
            "image": "https://static-files.cricket-australia.pulselive.com/headshots/288/10917-camedia.png"
          },
          {
            "fullName": "Rahul Dravid",
            "centuries": 48,
            "description": "Known as 'The Wall', Rahul Dravid is celebrated for his solid technique and temperament. He is one of the highest run-scorers in Test cricket.",
            "image": "https://images.news18.com/ibnlive/uploads/2021/01/1610343010_rtr2r0de-e1610343304291.jpg"
          },
          {
            "fullName": "Sourav Ganguly",
            "centuries": 38,
            "description": "A former captain, Sourav Ganguly is credited with instilling a sense of belief in the Indian team. He was known for his aggressive batting and leadership.",
            "image": "https://blackhattalent.com/wp-content/uploads/2023/07/Sourav-Ganguly11.webp"
          },
          {
            "fullName": "MS Dhoni",
            "centuries": 10,
            "description": "One of the most successful captains in cricket history, MS Dhoni is known for his calm demeanor and finishing ability, especially in limited-overs cricket.",
            "image": "https://cdn.britannica.com/25/222725-050-170F622A/Indian-cricketer-Mahendra-Singh-Dhoni-2011.jpg"
          }
        ]
      
      
